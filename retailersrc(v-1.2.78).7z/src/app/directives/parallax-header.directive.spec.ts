import { ParallaxHeaderDirective } from './parallax-header.directive';

describe('ParallaxHeaderDirective', () => {
  it('should create an instance', () => {
    const directive = new ParallaxHeaderDirective();
    expect(directive).toBeTruthy();
  });
});
