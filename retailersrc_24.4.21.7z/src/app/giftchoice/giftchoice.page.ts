import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-giftchoice',
  templateUrl: './giftchoice.page.html',
  styleUrls: ['./giftchoice.page.scss'],
})
export class GiftchoicePage implements OnInit {

  stock_name: any;
  gifts: any;

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {

    /**
     *  gift.checked : If set to true that radio will be checked by default on component load.
     *
     **/

    this.gifts.map(giftlist => {
      giftlist.map((gift, index) => {
        if (index == 0) {
          gift.checked = true;
        }
        else {
          gift.checked = false;
        }
      });
    });

    console.log(this.gifts);

  }


  dismiss() {
    this.modalCtrl.dismiss();
  }

}
