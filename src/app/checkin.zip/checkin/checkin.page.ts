import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { OnlineService } from '../services/online/online.service';
import { MessageService } from '../services/Messages/message.service';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { OfflineService } from '../services/offline/offline.service';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { UtilService } from '../services/util.service';
import { DatatransferService } from '../services/datatransfer/datatransfer.service';
import { NetworkService } from '../services/network/network.service';
import { LoadingService } from '../services/Loadings/loading.service';
import { ShopService } from '../services/shop/shop.service';
import { CartService } from '../services/cart/cart.service';

@Component({
  selector: 'app-checkin',
  templateUrl: './checkin.page.html',
  styleUrls: ['./checkin.page.scss'],
})
export class CheckinPage implements OnInit {

  lat: any;
  long: any;
  userName: any;
  spcode: any;
  shopbyUser: any = [];
  shopbyTeam: any = [];
  shopList: any = [];
  users: any = [];



  datetime: any;
  date: any;
  time: any;

  inventoryCheck: any;
  merchandizing: any;
  orderPlacement: any;
  shopName: any;
  currentType: any;

  address: any;
  shopsyskey: any;
  shopcode: any;
  loginData: any;
  currentDate: String = new Date().toISOString();
  searchToday: any;

  checkinDisabled: any = true;
  isLoading: any = false;

  checkintype: any;
  checkintypes: any = [{
    'id': 1,
    'name': "Check In",
  },
  {
    'id': 2,
    'name': "Store Closed",
  }
  ];

  constructor(
    private nativeStorage: NativeStorage,
    public modalCtrl: ModalController,
    public onlineService: OnlineService,
    public messageService: MessageService,
    public geolocation: Geolocation,
    public offlineService: OfflineService,
    private networkService: NetworkService,
    private locationAccuracy: LocationAccuracy,
    private util: UtilService,
    private dataTransfer: DatatransferService,
    private loadingService: LoadingService,
    private cartService: CartService,
    private shopService: ShopService
  ) {
    this.nativeStorage.getItem("loginData").then(res => {
      this.loginData = res;
      console.log("loginData -->" + JSON.stringify(this.loginData));
      this.today();
      this.getDatasforthispage();
    });
  }
  ngOnInit() {
    console.log(">>" + this.shopsyskey);

    this.locationAccuracy.canRequest().then((canRequest: any) => {
      // alert(canRequest);
      this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
        () => {
          console.log('Request successful');
          this.getLatandLong();
        },
        error => console.log('Error requesting location permissions', error)
      );
      // if(canRequest) {
      //   // the accuracy option will be ignored by iOS
      //
      //}
    });
  }
  checkNetwork() {
    this.networkService.checkNetworkStatus();
  }
  today() {
    let year = this.currentDate.substring(0, 4);
    let month = this.currentDate.substring(5, 7);
    let day = this.currentDate.substring(8, 10);
    this.searchToday = year + month + day;

  }

  async closeModal() {
    this.nativeStorage.remove("checkinShopdata");
    await this.modalCtrl.dismiss();
  }

  saveData() {
    if ((this.lat == "" || this.lat == undefined || this.lat == null) && (this.long == "" || this.long == undefined || this.long == null)) {
      this.messageService.showToast("Please open GPS.");
    }
    else {
      this.getLatandLong();
      this.getDateandtime();
      console.log("CurrentType>>" + this.currentType);
      if (this.currentType == 'TEMPCHECKOUT' || this.currentType == 'CHECKIN' || this.currentType == "STORECLOSED") {
        this.checkintype = 'Check In';
        console.log("checkintype" + this.checkintype);
        this.loadingService.loadingPresent();
        var params = {
          "lat": this.lat,
          "lon": this.long,
          "address": this.address,
          "shopsyskey": this.shopsyskey,
          "usersyskey": this.loginData.syskey,
          "checkInType": "CHECKIN",
          "register": false,
          "task": {
            "inventoryCheck": this.inventoryCheck,
            "merchandizing": this.merchandizing,
            "orderPlacement": this.orderPlacement,
            "print": "COMPLETED"
          }
        }
        console.log("param>><<<<<" + JSON.stringify(params));
        this.onlineService.checkIn(params).subscribe((res: any) => {
          console.log("-->" + JSON.stringify(res));
          if (res.status == "SUCCESS") {
            localStorage.setItem("sessionid", res.data.sessionid);
            for (var q = 0; q < this.shopbyUser.length; q++) {
              if (this.shopName == this.shopbyUser[q].shopname) {
                console.log("aa-->" + JSON.stringify(this.shopbyUser[q]));
                this.nativeStorage.setItem("checkinShopdata", this.shopbyUser[q]);
                break;
              }
            }
            var data: any = {
              "checkin": "true",
              "inventorycheck": this.inventoryCheck,
              "merchandizing": this.merchandizing,
              "orderplacement": this.orderPlacement,
              "date": this.util.getTodayDate()
            };
            this.nativeStorage.setItem("checkSteps", data);
            if (this.currentType == "TEMPCHECKOUT" || this.currentType == "CHECKIN") {
              var param = {
                'shopcode': this.shopcode,
                'date': this.util.getTodayDate(),
                'trantype': 'SalesOrder',
                'usersyskey': this.loginData.syskey
              };
              this.onlineService.getOrderList(param).subscribe((res: any) => {
                console.log("RES>>" + JSON.stringify(res));
                this.cartService.addToCartOrder(res.list);
                this.loadingService.loadingDismiss();
                this.messageService.showToast("Checkin successfully.");
                const check = {
                  checkin: 'In',
                  date: this.util.getTodayDate()
                }
                localStorage.setItem("checkin", JSON.stringify(check));

                this.modalCtrl.dismiss({ 'status': 'checkin' });
              });
            }
            else {
              this.loadingService.loadingDismiss();
              this.messageService.showToast("Checkin successfully.");
              const check = {
                checkin: 'In',
                date: this.util.getTodayDate()
              }
              localStorage.setItem("checkin", JSON.stringify(check));

              this.modalCtrl.dismiss({ 'status': 'checkin' });
            }

          }
          else {
            this.loadingService.loadingDismiss();
            this.messageService.showToast("Invalid checkin.");
          }
        },
          err => {
            console.log("err-->" + JSON.stringify(err));
            this.messageService.showNetworkToast(err);
            this.loadingService.loadingDismiss();
          })
      }
      else {
        if (this.checkintype == null || this.checkintype == "" || this.checkintype == undefined) {
          this.messageService.showToast("Please choose checkin type.");
        }
        else {
          console.log("checkintype" + this.checkintype);
          if (this.checkintype == 'Check In') {
            this.loadingService.loadingPresent();
            var params = {
              "lat": this.lat,
              "lon": this.long,
              "address": this.address,
              "shopsyskey": this.shopsyskey,
              "usersyskey": this.loginData.syskey,
              "checkInType": "CHECKIN",
              "register": false,
              "task": {
                "inventoryCheck": this.inventoryCheck,
                "merchandizing": this.merchandizing,
                "orderPlacement": this.orderPlacement,
                "print": "COMPLETED"
              }
            }
            console.log("param>><<<<<" + JSON.stringify(params));
            this.onlineService.checkIn(params).subscribe((res: any) => {
              console.log("-->" + JSON.stringify(res));
              if (res.status == "SUCCESS") {
                localStorage.setItem("sessionid", res.data.sessionid);
                for (var q = 0; q < this.shopbyUser.length; q++) {
                  if (this.shopName == this.shopbyUser[q].shopname) {
                    console.log("aa-->" + JSON.stringify(this.shopbyUser[q]));
                    this.nativeStorage.setItem("checkinShopdata", this.shopbyUser[q]);
                    break;
                  }
                }
                var data: any = {
                  "checkin": "true",
                  "inventorycheck": this.inventoryCheck,
                  "merchandizing": this.merchandizing,
                  "orderplacement": this.orderPlacement,
                  "date": this.util.getTodayDate()
                };
                this.nativeStorage.setItem("checkSteps", data);
                if (this.currentType == "TEMPCHECKOUT" || this.currentType == "CHECKIN") {
                  var param = {
                    'shopcode': this.shopcode,
                    'date': this.util.getTodayDate(),
                    'trantype': 'SalesOrder',
                    'usersyskey': this.loginData.syskey
                  };
                  this.onlineService.getOrderList(param).subscribe((res: any) => {
                    console.log("RES>>" + JSON.stringify(res));
                    this.cartService.addToCartOrder(res.list);
                    this.loadingService.loadingDismiss();
                    this.messageService.showToast("Checkin successfully.");
                    const check = {
                      checkin: 'In',
                      date: this.util.getTodayDate()
                    }
                    localStorage.setItem("checkin", JSON.stringify(check));

                    this.modalCtrl.dismiss({ 'status': 'checkin' });
                  });
                }
                else {
                  this.loadingService.loadingDismiss();
                  this.messageService.showToast("Checkin successfully.");
                  const check = {
                    checkin: 'In',
                    date: this.util.getTodayDate()
                  }
                  localStorage.setItem("checkin", JSON.stringify(check));

                  this.modalCtrl.dismiss({ 'status': 'checkin' });
                }

              }
              else {
                this.loadingService.loadingDismiss();
                this.messageService.showToast("Invalid checkin.");
              }
            },
              err => {
                console.log("err-->" + JSON.stringify(err));
                this.messageService.showNetworkToast(err);
                this.loadingService.loadingDismiss();
              })
          }
          else {
            for (var q = 0; q < this.shopbyUser.length; q++) {
              if (this.shopName == this.shopbyUser[q].shopname) {
                this.offlineService.updateshopUser(this.shopbyUser[q].id, "no", 'storeclosed').then(res => {
                  console.log("Update shopuser>>" + JSON.stringify(res));
                  this.modalCtrl.dismiss({ 'status': 'storeclosed', 'shop': this.shopbyUser[q] });
                });
                break;
              }
            }
          }
        }
      }

    }
  }
  getDatasforthispage() {
    this.shopbyUser = this.shopService.getShopByUser();
    this.userName = this.loginData.userName;
    console.log("userName -->" + this.userName);
    this.getDateandtime();
    var status = 0;
    for (var s = 0; s < this.shopbyUser.length; s++) {
      if (this.shopbyUser[s].shopsyskey == this.shopsyskey) {
        // this.address = this.shopbyUser[s].address;
        this.shopsyskey = this.shopbyUser[s].shopsyskey;
        this.shopcode = this.shopbyUser[s].shopcode;
        this.address = this.shopbyUser[s].address;
        // status = 1;
        break;
      }
    }

    // if (status == 0) {
    //   this.address = "Unregister";
    //   this.shopsyskey = "Unregister";
    // }
    // this.datetime = this.date + " - " + this.time;
  }
  formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
  }
  getDateandtime() {
    this.datetime = this.formatAMPM(new Date);
    this.date = new Date().toLocaleDateString();
    this.time = new Date().toLocaleTimeString();
  }
  getLatandLong() {
    this.geolocation.getCurrentPosition().then((resp) => {
      this.lat = resp.coords.latitude;
      this.long = resp.coords.longitude;
      setTimeout(() => {
        this.isLoading = true;
      }, 1000);
    }).catch((error) => {
      console.log('Error getting location', error);
    });
  }

  checkAddress() {
    for (var s = 0; s < this.shopbyUser.length; s++) {
      if (this.shopsyskey == this.shopbyUser[s].shopsyskey) {
        // if (this.shopbyUser[s].lat == this.lat && this.shopbyUser[s].long == this.long) {
        this.address = this.shopbyUser[s].address;
        this.shopsyskey = this.shopbyUser[s].shopsyskey;
        //   break;
        // } else {
        //   this.address = "Unregister";
        // }
      }
    }
  }

}
