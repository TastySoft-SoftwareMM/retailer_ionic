import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart/cart.service';
import { BehaviorSubject } from 'rxjs';
import { LoadingService } from '../services/Loadings/loading.service';
import { OfflineService } from '../services/offline/offline.service';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { OnlineService } from '../services/online/online.service';
import { MessageService } from '../services/Messages/message.service';
import { NavController, AlertController } from '@ionic/angular';
import { UtilService } from '../services/util.service';
import { DatatransferService } from '../services/datatransfer/datatransfer.service';

@Component({
  selector: 'app-cart-item',
  templateUrl: './cart-item.page.html',
  styleUrls: ['./cart-item.page.scss'],
})
export class CartItemPage implements OnInit {

  products = [];
  cart = [];
  subcart = [];
  allcart = [];
  shopinfo: any = [];
  returnedproduct: any = [];
  tabs: any = [];
  checkinshop: any = [];
  hiddenSearch: any;
  loginData: any;
  orderno: any;
  segment: any;
  params: any = this.getParams();
  child: any = [];
  subchild: any = []; //for orderlist offline
  stockbybrand: any = [];
  stockreturndata: any = [];
  cartItemCount: BehaviorSubject<number>;
  isLoading: any = false;
  open: any = false;
  constructor(private cartService: CartService, private loadingService: LoadingService,
    private offlineService: OfflineService,
    private onlineService: OnlineService,
    private nativeStorage: NativeStorage,
    private messageService: MessageService,
    private navCtrl: NavController,
    private alertCtrl: AlertController,
    private dataTransfer: DatatransferService,
    private util: UtilService) { }
  ngOnInit() {
    this.segment = 1;
    this.nativeStorage.getItem("loginData").then(res => {
      this.loginData = res;
      console.log("loginData -->" + JSON.stringify(this.loginData));
      this.cartItemCount = this.cartService.getCartItemCount();

      console.log("cart>>" + JSON.stringify(this.cart));
      this.getShopInfo();
    });
  }
  ionViewDidEnter() {
    console.log("cart>>" + JSON.stringify(this.cart));
    console.log("subcart>>" + JSON.stringify(this.subcart));
    console.log("allcart>>" + JSON.stringify(this.allcart));
    this.cartItemCount = this.cartService.getCartItemCount();
    this.returnedproduct = this.allcart.filter(el => el.expqty).map(val => {
      return val;
    });
  }
  toggleSection() {
    if (this.returnedproduct.length > 0) {
      this.open = !this.open;
    }
    else {
      this.messageService.showToast("No data");
    }
  }
  deleteCart(product) {
    this.tabs = [];
    this.loadingService.loadingPresent();
    this.cartService.deleteCart(product);
    this.getShopInfo();
    setTimeout(() => {
      this.loadingService.loadingDismiss();
    }, 2000);
  }
  getShopInfo() {
    this.nativeStorage.getItem("checkinShopdata").then(res => {
      this.checkinshop = res;
      this.shopinfo = [
        {
          'shop_name': res.shopname,
          'address': res.address,
          'date': this.util.getforShowDate()
        }
      ]
    });
    this.cart = this.cartService.getCart();
    this.subcart = this.cartService.getCart();
    this.allcart = this.cartService.getAllCart();
    this.returnedproduct = this.allcart.filter(el => el.expqty).map(val => {
      return val;
    });
    Array.from(new Set(this.cart.map(s => s.brandOwnerSyskey))).map(syskey => {
      return this.tabs.push({
        'name': this.allcart.find(s => s.brandOwnerSyskey === syskey).brandOwnerName,
        'brandOwnerSyskey': syskey
      });
    })

    setTimeout(() => {
      this.isLoading = true;
    }, 1000);
  }
  async addNote() {
    const alert = await this.alertCtrl.create({
      header: 'Add Note',
      inputs: [
        {
          type: 'text',
          placeholder: 'Enter Note'
        }
      ],
      buttons: [
        {
          text: 'Ok',
          handler: (data) => {
            for (var i = 0; i < this.cart.length; i++) {
              this.cart[i].note = data;
            }
          }
        }
      ]
    });
    await alert.present();
  }
  segmentChanged(ev: any) {
    console.log(ev);
    this.segment = ev.detail.value;
    console.log("seg>>" + this.segment);
    if (this.segment == 1) {
      this.cart = this.allcart.filter(el => !el.expqty);
    }
    else {
      const codes = this.subcart.map(el => el.brandOwnerSyskey);
      console.log("codes" + codes);
      this.cart = this.subcart.filter(el => el.brandOwnerSyskey == this.segment && !el.expqty);
      console.log(">>" + this.cart);
    }
  }
  increseCart(product) {
    this.cartService.increaseProdctCart(product);
  }
  decreseCart(product) {
    this.cartService.decreaseProductCart(product);
  }
  increaseReturnProduct(product) {
    this.cartService.increaseReturnProduct(product);
  }
  decreaseReturnProduct(product) {
    this.cartService.increaseReturnProduct(product);
  }
  getSubTotal() {
    return this.allcart.reduce((i, j) => i + j.price * j.amount, 0);
  }
  getTotal() {
    return this.allcart.reduce((i, j) => i + j.price * j.amount, 0);
  }
  getParams() {
    return { "syskey": '', "autokey": "", "createddate": '', "modifieddate": '', "userid": '', 'username': '', 'saveStatus': '', 'recordStatus': '', 'syncStatus': '', 'syncBatch': '', 'transType': '', 'manualRef': '', 'docummentDate': '', 'shopCode': '', 'currRate': '', 'totalamount': '', 'cashamount': '', 'discountamount': '', 'taxSyskey': '', 'taxPercent': '', 'taxAmount': '', 'previousId': '', 'stockByBrand': [] };
  }

  addReturnProduct() {
    this.navCtrl.navigateForward([`returnproduct`]);
  }
  orderSubmit() {
    if (this.cartItemCount.value == 0) {
      this.messageService.showToast("No data in shopping cart");
    }
    else {
      console.log("cart>>" + JSON.stringify(this.cart));
      console.log("subcart>>" + JSON.stringify(this.subcart));
      console.log("allcart>>" + JSON.stringify(this.allcart));
      this.params = this.getParams();
      this.loadingService.loadingPresent();
      this.orderno = "111" //orderno  update;
      this.params.syskey = "";
      this.params.autokey = "";
      this.params.createddate = "";
      this.params.modifieddate = "";
      this.params.userid = "";
      this.params.username = "";
      this.params.saveStatus = 1;
      this.params.recordStatus = 1;
      this.params.syncStatus = 1;
      this.params.syncBatch = "";
      this.params.transType = "SalesOrder";
      this.params.manualRef = "TBA";
      this.params.docummentDate = this.util.getTodayDate();
      this.params.shopCode = this.checkinshop.shopcode.toString();
      this.params.currRate = 1.0;
      this.params.cashamount = 1.0;
      this.params.discountamount = 1.0;
      this.params.taxSyskey = "0";
      this.params.taxPercent = 1.0;
      this.params.taxAmount = 1.0;
      this.params.previousId = "";
      this.params.totalamount = this.allcart.reduce((i, j) => i + j.price * j.amount, 0);
      const data = Array.from(new Set(this.allcart.map(s => s.brandOwnerSyskey))).map(syskey => {
        return {
          'brandOwnerCode': this.allcart.find(s => s.brandOwnerSyskey === syskey).brandOwnerCode,
          'brandOwnerName': this.allcart.find(s => s.brandOwnerSyskey === syskey).brandOwnerName,
          'whSyskey': this.allcart.find(s => s.brandOwnerSyskey === syskey).whSyskey,
          'brandOwnerSyskey': syskey
        };
      })
      console.log("brandOwnerdata>>>" + JSON.stringify(data));
      data.filter(bobj => {
        this.stockbybrand = [];
        this.stockreturndata = [];
        this.child = [];
        //---------part of Stockbybrand [start]-------------
        var stockdata;
        this.stockbybrand.push({
          "syskey": "",
          "autokey": "",
          "createdate": "",
          "modifieddate": "",
          "userid": "",
          "username": '',
          "saveStatus": 1,
          "recordStatus": 1,
          "syncStatus": 1,
          "syncBatch": "",
          "transType": "SalesOrder",
          "transId": "",
          "docummentDate": this.util.getTodayDate(),
          "brandOwnerCode": bobj.brandOwnerCode,
          "brandOwnerName": bobj.brandOwnerName,
          "brandOwnerSyskey": bobj.brandOwnerSyskey,
          "orderSyskey": "",
          "totalamount": 0.0,
          "cashamount": 0.0,
          "discountamount": 0.0,
          "taxSyskey": "",
          "taxAmount": 0.0,
          "stockData": [],
          "stockReturnData": []
        });
        stockdata = this.allcart.filter(el => el.brandOwnerSyskey == bobj.brandOwnerSyskey && !el.expqty);
        stockdata.filter(sobj => {
          this.child.push({
            "syskey": "",
            "stockCode": sobj.code,
            "saleCurrCode": "MMK",
            "n1": "",
            "wareHouseSyskey": sobj.whSyskey,
            "binSyskey": "0",
            "qty": sobj.amount,
            "lvlSyskey": "390398473894233",
            "lvlQty": 0,
            "n8": 0.0,
            "n9": 0.0,
            "taxAmount": 0.0,
            "totalAmount": Number(sobj.price) * Number(sobj.amount),
            "taxCodeSK": "0",
            "isTaxInclusice": 0,
            "taxPercent": 0.0
          });
        });
        this.child.filter(obj => {
          this.stockbybrand.reduce((i, j) => i + j.stockData.push(obj), 0);
        });
        //--------part of stockbybrand [end]---------

        //--------part of stockreturndata [start]---------

        const returnstockdata = this.allcart.filter(el => el.brandOwnerSyskey == bobj.brandOwnerSyskey && el.expqty).map(val => {
          return val;
        });
        console.log("Returnstockdata>>" + JSON.stringify(returnstockdata));
        returnstockdata.filter(sobj => {
          this.stockreturndata.push({
            "syskey": "",
            "stockCode": sobj.code,
            "saleCurrCode": "MMK",
            "n1": "",
            "wareHouseSyskey": sobj.whSyskey,
            "binSyskey": "0",
            "qty": sobj.amount,
            "lvlSyskey": "390398473894233",
            "lvlQty": 0,
            "n8": 0.0,
            "n9": 0.0,
            "taxAmount": 0.0,
            "totalAmount": Number(sobj.price) * Number(sobj.amount),
            "taxCodeSK": "0",
            "isTaxInclusice": 0,
            "taxPercent": 0.0
          });
        });
        this.stockbybrand.filter(obj => {
          if (obj) {
            console.log("stockfdskjl>" + JSON.stringify(obj));
            this.params.stockByBrand.push(obj);
          }
        });
        this.stockreturndata.filter(obj => {
          this.stockbybrand.reduce((i, j) => i + j.stockReturnData.push(obj), 0);
        });
        //--------part of stockreturndata [start]---------
      });
      console.log("paramsaleorder>>" + JSON.stringify(this.params));
      setTimeout(() => {
        this.onlineService.saveOrder(this.params).subscribe((res: any) => {
          console.log("Save order==>" + JSON.stringify(res));
          if (res.status == "SUCCESS") {
            this.cartService.clearCart();
            var data: any = {
              "checkin": "true",
              "inventorycheck": "true",
              "merchandizing": "true",
              "orderplacement": "true"
            };
            this.nativeStorage.setItem("checkSteps", data);
            this.cartService.produceAmount();
            localStorage.setItem('routestatus', 'ordersubmit');
            this.checkOut();
            this.dataTransfer.clearDataInventory();
            this.loadingService.loadingDismiss();
            this.navCtrl.navigateBack([`main`]);
            this.messageService.showToast("Saved successfully.");
          }
          else {
            this.loadingService.loadingDismiss();
            this.messageService.showToast("Something wrong!.");
          }
        }, err => {
          console.log("err=>" + JSON.stringify(err));
          this.loadingService.loadingDismiss();
          this.messageService.showNetworkToast(err);
        });
      }, 100);
    }
  }

  checkOut() {
    this.offlineService.updateshopUser(this.checkinshop.id, 'no', "complete").then(res => {
      console.log("Update shopuser>>" + JSON.stringify(res));
    });
    const check = {
      checkin: 'out',
      date: this.util.getTodayDate()
    }
    this.offlineService.deleteInventory();
    if (this.cart.length == 0) {
      localStorage.setItem("checkin", JSON.stringify(check));
      this.removeNative();
    } else {
      localStorage.setItem("checkin", JSON.stringify(check));
      this.removeNative();
    }
  }
  removeNative() {
    this.nativeStorage.remove("checkSteps");
    this.nativeStorage.remove("checkinShopdata");
  }
}

