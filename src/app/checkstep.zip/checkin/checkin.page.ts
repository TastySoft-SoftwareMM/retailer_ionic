import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { OnlineService } from '../services/online/online.service';
import { MessageService } from '../services/Messages/message.service';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { OfflineService } from '../services/offline/offline.service';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { UtilService } from '../services/util.service';
import { DatatransferService } from '../services/datatransfer/datatransfer.service';

@Component({
  selector: 'app-checkin',
  templateUrl: './checkin.page.html',
  styleUrls: ['./checkin.page.scss'],
})
export class CheckinPage implements OnInit {

  lat: any;
  long: any;
  userName: any;
  spcode: any;
  checkinDisabled: any = true;
  shopbyUser: any = [];
  shopbyTeam: any = [];
  users: any = [];
  datetime: any;
  date: any;
  time: any;
  shopList: any = [];
  address: any;
  shopcode: any;
  shopName: any;
  loginData: any;
  currentDate: String = new Date().toISOString();
  searchToday: any;
  constructor(
    private nativeStorage: NativeStorage,
    public modalCtrl: ModalController,
    public onlineService: OnlineService,
    public messageService: MessageService,
    public geolocation: Geolocation,
    public offlineService: OfflineService,
    private locationAccuracy: LocationAccuracy,
    private util: UtilService,
    private dataTransfer: DatatransferService
  ) {
    this.nativeStorage.getItem("loginData").then(res => {
      this.loginData = res;
      console.log("loginData -->" + JSON.stringify(this.loginData));
      this.today();
      this.getDatasforthispage();
    });
  }
  ngOnInit() {
    this.locationAccuracy.canRequest().then((canRequest: any) => {
      // alert(canRequest);
      this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
        () => {
          console.log('Request successful');
          this.getLatandLong();
        },
        error => console.log('Error requesting location permissions', error)
      );
      // if(canRequest) {
      //   // the accuracy option will be ignored by iOS
      //
      // }
    });
  }
  today() {
    let year = this.currentDate.substring(0, 4);
    let month = this.currentDate.substring(5, 7);
    let day = this.currentDate.substring(8, 10);
    this.searchToday = year + month + day;

  }

  async closeModal() {
    this.nativeStorage.remove("checkinShopdata");
    await this.modalCtrl.dismiss();
  }

  saveData() {
    if ((this.lat == "" || this.lat == undefined || this.lat == null) && (this.long == "" || this.long == undefined || this.long == null)) {
      this.messageService.showToast("Please open GPS.");
    } else if (this.shopName == null || this.shopName == "" || this.shopName == undefined) {
      this.messageService.showToast("Please choose shop.");
    } else {
      this.getLatandLong();
      this.getDateandtime();
      var params = {
        "lat": this.lat,
        "lon": this.long,
        "spcode": "",
        "address": this.address,
        "shopcode": this.shopcode,
        "shoplocsyskey": "",
        "rpcode": "",
        "rcode": "",
        "date": this.date + " " + this.time
      }
      console.log("param>>" + JSON.stringify(params));
      
      this.onlineService.checkIn(params).subscribe((res: any) => {
        console.log("-->" + JSON.stringify(res));
        if (res.status == "SUCCESS!") {
          for (var q = 0; q < this.shopbyUser.length; q++) {
            if (this.shopName == this.shopbyUser[q].shopname) {
              console.log("aa-->" + JSON.stringify(this.shopbyUser[q]));
              this.nativeStorage.setItem("checkinShopdata", this.shopbyUser[q]);
              // this.dataTransfer.setCheckinShop(this.shopbyUser[q]);
              // this.offlineService.updateshopUser(this.shopbyUser[q].id, "no", 'pending').then(res => {
              //   console.log("Update shopuser>>" + JSON.stringify(res));
              // });
              break;
            }
          }
          var data: any = {
            "checkin": "true",
            "inventorycheck": "false",
            "merchandizing": "false",
            "orderplacement": "false"
          };
          this.nativeStorage.setItem("checkSteps", data);

          this.messageService.showToast("Checkin successfully.");
          const check = {
            checkin: 'In',
            date: this.util.getTodayDate()
          }
          localStorage.setItem("checkin", JSON.stringify(check));
          this.modalCtrl.dismiss();
        }
      },
        err => {
          console.log("err-->" + JSON.stringify(err));
          this.messageService.showNetworkToast(err);

        })
    }
  }
  getDatasforthispage() {
    this.offlineService.getdatasfromShopbyteam(this.searchToday, 'yes', this.loginData.userId).then((shopbyTeam: any) => {
      console.log("shopbyTeam-->" + JSON.stringify(shopbyTeam));
      if (shopbyTeam.rows > 0) {
        this.shopbyTeam = shopbyTeam.data;
      }
    })
      .catch(shopbyTeam_err => {
        console.log("shopbyTeam_err-->" + JSON.stringify(shopbyTeam_err));
      });
    this.offlineService.getShopUserByIsActive(this.searchToday, 'yes', this.loginData.userId).then((shopbyUser: any) => {
      console.log("shopbyUser-->" + JSON.stringify(shopbyUser));
      if (shopbyUser.rows > 0) {
        this.shopbyUser = shopbyUser.data;
        this.userName = this.loginData.userName;
        console.log("userName -->" + this.userName);
        this.spcode = this.shopbyUser[0].usercode;
      }
    })
      .catch(shopbyUser_err => {
        console.log("shopbyUser_err-->" + JSON.stringify(shopbyUser_err));
      })
    this.getDateandtime();
    var status = 0;
    for (var s = 0; s < this.shopbyUser.length; s++) {
      if (this.shopbyUser[s].lat == this.lat && this.shopbyUser[s].long == this.long) {
        // this.address = this.shopbyUser[s].address;
        this.shopcode = this.shopbyUser[s].shopcode;
        status = 1;
        break;
      }
    }

    if (status == 0) {
      this.address = "Unregister";
      this.shopcode = "Unregister";
    }
    this.datetime = this.date + " - " + this.time;
  }

  getDateandtime() {
    this.date = new Date().toLocaleDateString();
    this.time = new Date().toLocaleTimeString();
  }

  getLatandLong() {
    this.geolocation.getCurrentPosition().then((resp) => {
      this.lat = resp.coords.latitude;
      this.long = resp.coords.longitude;
    }).catch((error) => {
      console.log('Error getting location', error);
    });
  }

  checkAddress() {
    for (var s = 0; s < this.shopbyUser.length; s++){
      if (this.shopName == this.shopbyUser[s].shopname) {
        if (this.shopbyUser[s].lat == this.lat && this.shopbyUser[s].long == this.long) {
          // this.address = this.shopbyUser[s].address;
          this.shopcode = this.shopbyUser[s].shopcode;
          break;
        } else {
          this.address = "Unregister";
        }
      }
    }
  }

}
