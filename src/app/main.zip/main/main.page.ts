import { Component, OnInit } from '@angular/core';
import { AlertController, ModalController, NavController, MenuController } from '@ionic/angular';
import { CheckinPage } from '../checkin/checkin.page';
import { OfflineService } from '../services/offline/offline.service';
import { MessageService } from '../services/Messages/message.service';
import { BehaviorSubject } from 'rxjs';
import { CartService } from '../services/cart/cart.service';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { UtilService } from '../services/util.service';
import { OnlineService } from '../services/online/online.service';
import { DataService } from '../services/data.service';
import { DatatransferService } from '../services/datatransfer/datatransfer.service';
import { NetworkService } from '../services/network/network.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-main',
  templateUrl: './main.page.html',
  styleUrls: ['./main.page.scss']
})

export class MainPage implements OnInit {

  checkinShopdata: any;
  loginData: any;
  checkinandoutStatus: any;
  merchandizing: any = false;
  saleandStoreownver: any = false;
  stockall: any = [];
  shopbyUser: any = [];
  cart: any = [];
  selectshop: any;

  datas: any = [1, 2, 3, 4, 5, 6, 7, 8, 9];
  checkout: any = false;
  profile: any;
  cartItemCount: BehaviorSubject<number>;
  checkstep: any = {};
  orderno: any;
  shopDatalength: any;

  constructor(
    private onlineService: OnlineService,
    private nativeStorage: NativeStorage,
    private alertCtrl: AlertController,
    private modalCtrl: ModalController,
    public offlineService: OfflineService,
    public navCtrl: NavController,
    public messageService: MessageService,
    private menu: MenuController,
    private cartService: CartService,
    private util: UtilService,
    private dataTransfer: DatatransferService,
    private networkService: NetworkService,
    private activateRoute: ActivatedRoute
  ) {
    this.nativeStorage.getItem("loginData").then(res => {
      this.loginData = res;
      console.log("loginData -->" + JSON.stringify(this.loginData));
      if (this.loginData.merchandizer == "Yes") {
        this.merchandizing = true;
      } else {
        this.merchandizing = false;
      }
      if (this.loginData.userType == "saleperson" || this.loginData.userType == "storeowner") {
        this.saleandStoreownver = true;
      } else {
        this.saleandStoreownver = false;
      }
      this.networkService.checkNetworkStatus();
      this.getAllDataforMain();
    });
  }
  ngOnInit() {
    this.cartItemCount = this.cartService.getCartItemCount();
    this.cart = this.cartService.getCart();
    this.getProfile();
  }
  ionViewWillEnter() {
    this.checkInandout();
    if (localStorage.getItem('routestatus') == "ordersubmit") {  // for route from order submit reload data
      this.shopbyUser = [];
      this.getAllDataforMain();
    }
  }
  getProfile() {
    if (localStorage.getItem("loginData"))
      this.profile = JSON.parse(localStorage.getItem("loginData"));
  }
  async selectShop(shop) {
    console.log("select shop>>" + JSON.stringify(shop));
    if (this.checkout == false) {
      if (shop.checkinStuats == null) {
        this.selectshop = shop;
        const modal = await this.modalCtrl.create({
          component: CheckinPage,
          cssClass: 'modalStyle',
          componentProps: {
            address: this.selectshop.address,
            shopName: this.selectshop.shopname
          }
        });
        await modal.present();
        var data: any;
        data = await modal.onDidDismiss();
        if (data) {
          this.checkInandout();
          var datas: any;
          this.nativeStorage.getItem("checkinShopdata").then(res => {
            if (res !== null || res !== undefined) {
              datas = res;
              this.checkinShopdata = res;
              console.log("rr-->" + JSON.stringify(res));
              console.log("datas-->" + JSON.stringify(datas));
              for (var w = 0; w < this.shopbyUser.length; w++) {
                if (this.shopbyUser[w].shopname == datas.shopname) {
                  this.shopbyUser[w].checkinStuats = "pending";
                  this.offlineService.updateshopUser(datas.id, 'no', 'pending').then(res => {
                    console.log("Update shopuser>>" + JSON.stringify(res));
                    this.checkout = true;
                  });
                }
              }
            }
          });
        }
      }
    }

  }
  async workData_1(data) {
    this.workSteps();
    console.log("check>>" + this.checkout);
    if (data == "checkin") {
      if (this.checkout == false) {
        if (this.shopbyUser.length == 0) {
          this.messageService.showToast("Need shop datas");
        } else {
          this.messageService.showToast("Select shop");
        }
      }
      else { //checkout
        const alert = await this.alertCtrl.create({
          header: 'Confirm',
          message: 'Are you sure?',
          buttons: [
            {
              text: 'Cancel',
              role: 'cancel',
              handler: () => {
                console.log('Confirm Cancel: blah');
              }
            }, {
              text: 'Okay',
              handler: () => {
                this.checkOutFunction();
              }
            }
          ]
        });
        await alert.present();
      }
    } else if (data == "inventorycheck") {
      // this.navCtrl.navigateForward(['inventorycheck']);
      console.log("checkstep>>" + JSON.stringify(this.checkstep));

      setTimeout(() => {
        if (this.checkstep.checkin == "true") {
          var params = {
            "shopsyskey": "1809201409169561279",
            // this.checkinShopdata.shopsyskey,
            "maxline": 5
          }
          this.dataTransfer.clearDataInventory();
          this.onlineService.getInventory(params).subscribe((res: any) => {
            if (res.list.length == 0) {
              this.messageService.showToast("No data for Inventory Check");
              var data: any = {
                "checkin": "true",
                "inventorycheck": "true",
                "merchandizing": "false",
                "orderplacement": "false"
              };
              this.nativeStorage.setItem("checkSteps", data);
            } else {
              this.dataTransfer.setData(res.list);
              this.navCtrl.navigateForward(['inventorycheck']);
            }
          }, err => {
            console.log("err>>" + JSON.stringify(err));
            this.messageService.showNetworkToast(err);
          });
        } else {
          this.messageService.showToast("Need to do 1.Check In");
          console.log("12-->" + "Testing");
        }
      }, 100);
    } else if (data == "orderPlacement") {
      setTimeout(() => {
        if (this.merchandizing == false) {
          if (this.checkstep.checkin == "true" && this.checkstep.inventorycheck == "true") {
            var data: any = {
              "checkin": "true",
              "inventorycheck": "true",
              "merchandizing": "true",
              "orderplacement": "false"
            };
            this.nativeStorage.setItem("checkSteps", data);
            this.navCtrl.navigateForward(['order-placement']);
          }
          else if (this.checkstep.checkin == "true" && this.checkstep.inventorycheck == "false") {
            this.messageService.showToast("Need to do  3.Inventory Check");
          }
          else {
            this.messageService.showToast("Need to do 1.Check In and 2.Inventory Check");
          }
        }
        else {
          if (this.checkstep.checkin == "true" && this.checkstep.inventorycheck == "true" && this.checkstep.merchandizing == "true") {
            var data: any = {
              "checkin": "true",
              "inventorycheck": "true",
              "merchandizing": "true",
              "orderplacement": "false"
            };
            this.nativeStorage.setItem("checkSteps", data);
            this.navCtrl.navigateForward(['order-placement']);
          } else if (this.checkstep.checkin == "true" && this.checkstep.inventorycheck == "false") {
            this.messageService.showToast("Need to do 2.Inventory Check 3.Merchandizing");
          }
          else if (this.checkstep.inventorycheck == "true" && this.checkstep.merchandizing == "false") {
            this.messageService.showToast("Need to do  3.Merchandizing");
          }
          else {
            this.messageService.showToast("Need to do 1.Check In and 2.Inventory Check 3.Merchandizing");
          }
        }

      }, 100);
    } else {
      this.checkInandout();
      setTimeout(() => {
        if (this.checkstep.checkin == "true" && this.checkstep.inventorycheck == "false") {
          this.messageService.showToast("Need to do 2.Inventory Check");
        } else if (this.checkstep.checkin == "false" && this.checkstep.inventorycheck == "false") {
          this.messageService.showToast("Need to do 1.Check In and 2.Inventory Check");
        }
        else {
          if (this.checkstep.checkin == "true" && this.checkstep.inventorycheck == "true") {
            console.log("checkinshop>>" + JSON.stringify(this.checkinShopdata));
            this.onlineService.getMerchandizing(this.checkinShopdata.shopsyskey).subscribe((res: any) => {
              console.log("rs-->" + JSON.stringify(res));
              if (res.list.length == 0) {
                this.messageService.showToast("No data for Merchandizing");
                var data: any = {
                  "checkin": "true",
                  "inventorycheck": "true",
                  "merchandizing": "true",
                  "orderplacement": "false"
                };
                this.nativeStorage.setItem("checkSteps", data);
              } else {
                this.dataTransfer.setData(res.list);
                this.navCtrl.navigateForward(['merchandizing']);
              }
            }, err => {
              this.messageService.showNetworkToast(err);
            });
          }
        }
      }, 100);
    }
  }
  workData(data) {
    if (data == "menu") {
      this.navCtrl.navigateForward(['menu']);
    } else if (data == "profile") {
      this.menu.enable(true, 'first');
      this.menu.close('first');
      this.navCtrl.navigateForward(['profile']);
    } else if (data == "shopcart") {
      if (this.cartItemCount.value == 0) {
        this.messageService.showToast("No data in shopping cart");
      }
      else {
        this.navCtrl.navigateForward(['cart-item']);
      }
    }
  }
  // async checkOut() {

  // }
  checkOutFunction() {
    this.nativeStorage.getItem("checkinShopdata").then(res => {
      this.messageService.showToast("Checkout successfully.");
      var status: any;
      this.nativeStorage.getItem("checkSteps").then(ress => {
        console.log("00->" + JSON.stringify(ress));
        status = ress;
        var checkinStuats: any;
        if (status.checkin == "true" && status.inventorycheck == "true" && status.merchandizing == "true" && status.orderplacement == "true") {
          checkinStuats = "complete";
        } else {
          checkinStuats = "incomplete";
        }
        var datas: any;
        this.nativeStorage.getItem("checkinShopdata").then(res => {
          console.log("23->" + JSON.stringify(res));
          datas = res;
          for (var w = 0; w < this.shopbyUser.length; w++) {
            if (this.shopbyUser[w].shopname == datas.shopname) {
              this.shopbyUser[w].checkinStuats = checkinStuats;
              this.checkout = false;
              this.offlineService.updateshopUser(datas.id, 'no', checkinStuats).then(res => {
                console.log("Update shopuser>>" + JSON.stringify(res));
              });
              const check = {
                checkin: 'out',
                date: this.util.getTodayDate()
              }
              this.offlineService.deleteInventory();
              if (this.cart.length == 0) {
                localStorage.setItem("checkin", JSON.stringify(check));
                this.removeNative();
              } else {
                localStorage.setItem("checkin", JSON.stringify(check));
                this.removeNative();
              }
              break;
            }
          }
        })
          .catch(err => {
            console.log("ers-->" + JSON.stringify(err));
          });
      })
        .catch(err => {
          console.log("err23-->" + JSON.stringify(err));
        });
    }, err => {
      console.log("err >>" + JSON.stringify(err));
      this.checkout = false;
    });
  }
  checkInandout() {
    this.nativeStorage.getItem('checkinShopdata').then(res => {
      console.log("shop>>" + JSON.stringify(res));
      this.checkinShopdata = res;
    })
    var aa = JSON.parse(localStorage.getItem("checkin"));
    console.log("aa>>" + JSON.stringify(aa));
    if (aa == null || aa == undefined) {
      this.checkout = false;
    }
    else {
      if (aa.date == this.util.getTodayDate()) {
        if (aa.checkin == "In") {
          this.checkout = true;
        } else {
          this.checkout = false;
        }
      }
      else {
        this.checkout = false;
      }
    }
  }
  getAllDataforMain() {
    this.offlineService.getStockall().then((res: any) => {
      console.log("res-->" + JSON.stringify(res));
      if (res.rows > 0) {
        this.stockall = res.data;
      }
    })
      .catch(err => {
        console.log("err-->" + JSON.stringify(err));
      });
    this.offlineService.getdatasfromShopbyuser(this.util.getTodayDate(), this.loginData.userId).then((shop_res: any) => {
      console.log("shop_res-->" + JSON.stringify(shop_res));
      if (shop_res.rows > 0) {
        this.shopDatalength = shop_res.data.length;
        for (var qe = 0; qe < shop_res.data.length; qe++) {
          this.shopbyUser.push(
            {
              id: shop_res.data[qe].id,
              address: shop_res.data[qe].address,
              shopsyskey: shop_res.data[qe].shopsyskey,
              shopname: shop_res.data[qe].shopname,
              long: shop_res.data[qe].long,
              phoneno: shop_res.data[qe].phoneno,
              zonecode: shop_res.data[qe].zonecode,
              shopcode: shop_res.data[qe].shopcode,
              teamcode: shop_res.data[qe].teamcode,
              location: shop_res.data[qe].location,
              usercode: shop_res.data[qe].usercode,
              user: shop_res.data[qe].user,
              lat: shop_res.data[qe].lat,
              email: shop_res.data[qe].email,
              username: shop_res.data[qe].username,
              checkinStuats: shop_res.data[qe].status
            }
          );
        }
      } else {
        this.shopDatalength = 0;
      }
      localStorage.removeItem('routestatus');
    })
      .catch(shop_err => {
        console.log("shop_err-->" + JSON.stringify(shop_err));
      });
    this.workSteps();
  }
  openFirst() {
    this.menu.enable(true, 'first');
    this.menu.open('first');
  }

  menuworkData(data) {
    if (data == "orderlist") {
      this.menu.enable(true, 'first');
      this.menu.close('first');
      this.navCtrl.navigateForward(['order-list']);
    }
  }

  workSteps() {
    this.checkinandoutStatus = JSON.parse(localStorage.getItem("checkin"));
    if (this.checkinandoutStatus == null || this.checkinandoutStatus == undefined) {
      this.checkstep = {
        "checkin": "false",
        "inventorycheck": "false",
        "merchandizing": "false",
        "orderplacement": "false"
      };
    }
    else {
      if (this.checkinandoutStatus.checkin == "In") {
        this.nativeStorage.getItem("checkSteps").then(res => {
          if (res == undefined || res == null) {
            this.checkstep = {
              "checkin": "false",
              "inventorycheck": "false",
              "merchandizing": "false",
              "orderplacement": "false"
            };
          } else {
            this.checkstep = res;
          }
        });
      } else {
        this.checkstep = {
          "checkin": "false",
          "inventorycheck": "false",
          "merchandizing": "false",
          "orderplacement": "false"
        };
      }
    }

  }

  removeNative() {
    this.nativeStorage.remove("checkSteps");
    this.nativeStorage.remove("checkinShopdata");
  }
}
