import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ModalController, ActionSheetController, Platform, LoadingController } from '@ionic/angular';



import { Camera, CameraOptions, PictureSourceType } from '@ionic-native/camera/ngx';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { File, FileEntry } from '@ionic-native/file/ngx';
import { FilePath } from '@ionic-native/file-path/ngx';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { WebView } from '@ionic-native/ionic-webview/ngx';
import { Base64 } from '@ionic-native/base64/ngx';



import { UtilService } from '../services/util.service';
import { OfflineService } from '../services/offline/offline.service';
import { MessageService } from '../services/Messages/message.service';
import { DomSanitizer } from '@angular/platform-browser';
import { OnlineService } from '../services/online/online.service';
import { LoadingService } from '../services/Loadings/loading.service';
import { ImageViewerPage } from '../image-viewer/image-viewer.page';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { NetworkService } from '../services/network/network.service';
import { DatatransferService } from '../services/datatransfer/datatransfer.service';
import { MerchandizingService } from '../services/merchandizing/merchandizing.service';

const Store_KEY = "taskone";

@Component({
  selector: 'app-merchan-modal',
  templateUrl: './merchan-modal.page.html',
  styleUrls: ['./merchan-modal.page.scss'],
})
export class MerchanModalPage implements OnInit {
  images: any = [];
  secondImages: any = [];
  uimages: any = [];
  passVal: any;
  campaign: any;
  brandownername: any;
  brandownercode: any;
  taskId: any;
  taskCode: any;
  taskName: any;

  remark: any;

  t1: any;
  t2: any;
  t3: any;
  checkinShopdata: any;
  params: any = [];
  loading: any;
  check_merchandizing_view_only: any;
  picsum: string[] = Array.from(
    new Array(12),
    (x, i) => `https://source.unsplash.com/random/1080x720?${i}`
  );

  isLoading: any = false;
  constructor(private modalCtrl: ModalController,
    private sanitizer: DomSanitizer,
    private statusBar: StatusBar,
    private camera: Camera,
    private nativeStorage: NativeStorage,
    private actionSheetCtrl: ActionSheetController,
    private file: File,
    private filepath: FilePath,
    private filetransfer: FileTransfer,
    private webview: WebView,
    private ref: ChangeDetectorRef,
    private util: UtilService,
    private platform: Platform,
    private offlineService: OfflineService,
    private onlineService: OnlineService,
    private base64: Base64,
    private loadingService: LoadingService,
    private loadingController: LoadingController,
    private networkService: NetworkService,
    private messageService: MessageService,
    private dataTransfer: DatatransferService,
    private merchandizingService: MerchandizingService) {
    this.loadingService.loadingPresent();
    this.check_merchandizing_view_only = localStorage.getItem("MerchandizingViewOnly");
    console.log(this.check_merchandizing_view_only);
    this.nativeStorage.getItem("checkinShopdata").then((res: any) => {
      console.log("121-->" + JSON.stringify(res));
      this.checkinShopdata = res;
      this.getData();
    });
  }

  ngOnInit() {

  }
  checkNetwork() {
    this.networkService.checkNetworkStatus();
  }
  dismissModal() {
    this.modalCtrl.dismiss();
  }
  async imagePicker() {
    const actionsheet = await this.actionSheetCtrl.create({
      header: 'Select One',
      buttons: [
        {
          text: 'Gallery',
          icon: 'images-outline',
          cssClass: 'gallery',
          handler: () => {
            this.takePicture(this.camera.PictureSourceType.PHOTOLIBRARY, "gallery");
          }
        },
        {
          text: 'Take Photo',
          icon: 'camera-outline',
          handler: () => {
            this.takePicture(this.camera.PictureSourceType.CAMERA, "camera");
          }
        },
        {
          text: 'Cancel',
          icon: 'close',
          role: 'cancel'
        }
      ]
    });
    await actionsheet.present();
  }
  getData() {
    // var url = "C:\\Users\\hhs\\Pictures\\merchandisingimg\\1\\20200503\\1002\\20200503115422T00674.jpeg";
    // var ret = url.split("\\").reduce((p, c, i, arr) => { if (i >= arr.length - 1) { return c } });
    // var ret = url.split("\\").reduce((p, c, i, arr) => { if (i >= arr.length - 1) { return (p ? ("\\" + p) } });
    // console.log(">>" + ret);
    this.offlineService.getMerchTask(this.checkinShopdata.shopcode, this.taskId, this.util.getTodayDate()).then((res: any) => {
      console.log("list1 ==>" + JSON.stringify(res));
      res.data.filter(obj => {
        this.file.listDir(this.file.externalApplicationStorageDirectory, obj.dir).then((list) => {
          console.log("list1 ==>" + JSON.stringify(list));
          for (let data of list) {
            if (data.isFile == true) {
              this.filepath.resolveNativePath(data.nativeURL).then(nPath => {
                var path = this.webview.convertFileSrc(nPath);
                console.log("path>>" + path);
                this.images.push(
                  {
                    "name": data.name,
                    "dir": obj.dir,
                    "img": path,
                    "status": "uploaded"
                  }
                )

              })
            }
          }
        });
      })
    });

    setTimeout(() => {
      this.loadingController.getTop().then(hasLoading => {
        if (hasLoading) {
          this.loadingService.loadingDismiss();
          this.isLoading = true;
        }
      });
    }, 2000);
  }
  pathForImage(img) {
    if (img == null) {
      return '';
    }
    else {
      let converted = this.webview.convertFileSrc(img);
      return converted;
    }
  }
  takePicture(sourceType: PictureSourceType, type) {
    const options: CameraOptions = {
      quality: 80,
      sourceType: sourceType,
      correctOrientation: true,
      saveToPhotoAlbum: false,
      mediaType: this.camera.MediaType.PICTURE,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
    }
    this.camera.getPicture(options).then((imageData) => {
      if (type == "gallery") {
        var index = imageData.toString().indexOf("?");
        imageData = imageData.substring(0, index);
      }
      var newFileName = this.util.getTodayDate() + this.util.getCurrentTime() + ".jpg";
      console.log("1123-->" + newFileName + "____________");
      var imageName = newFileName.replace(".jpg", "");
      this.base64.encodeFile(imageData).then((base64File: string) => {
        console.log("images1214-->" + base64File);
        var filePath = this.checkinShopdata.shopsyskey + '/' + this.util.getTodayDate() + '/' + this.passVal + '/' + this.campaign;
        this.params.push(
          {
            "path": filePath + newFileName,
            "name": imageName,
            "img": base64File.replace("data:image/*;charset=utf-8;base64,", "data:image/jpeg;base64,")
          }
        );
        // console.log("params12-->" + JSON.stringify(this.params));
      }, (err) => {
        console.log("err-->" + JSON.stringify(err));
      });
      this.images.push({
        "img": this.webview.convertFileSrc(imageData),
        "name": imageName,
        "status": "notUpload"
      })
      console.log("imagesArray-->" + JSON.stringify(this.images));
      this.createDirectory();

    }, (err) => {
    });
  }
  b64toBlob(b64Data, contentType) {
    contentType = contentType || '';
    var sliceSize = 512;
    var byteCharacters = window.atob(b64Data);
    var byteArrays = [];
    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);
      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      var byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    var blob = new Blob(byteArrays, { type: contentType });
    return blob;
  }
  closePicture(index, data) {
    console.log("Index==>" + index);

    if (this.images.length == 1) {
      this.merchandizingService.updateTaskStatus(this.taskId);
    }
    this.images.splice(index, 1);

    if (data.status === "uploaded") {
      this.file.removeFile(this.file.externalApplicationStorageDirectory + data.dir, data.name).then(val => {
        console.log("File removed" + JSON.stringify(this.file));
        var name = data.name.substring(0, data.name.indexOf('.'));
        console.log("name>>" + name);
        console.log(">>>" + JSON.stringify(val));
        if (this.images.length == 1) {
          this.offlineService.deleteMerchTask(this.checkinShopdata.shopcode, this.passVal, this.taskId, this.util.getTodayDate()).then(res => {
            console.log("Delete merch task ==" + JSON.stringify(res));
          });
        }
        this.offlineService.deleteMerchImage(name, this.util.getTodayDate()).then(res => {
          console.log("deleteres>>>" + JSON.stringify(res));
          this.offlineService.getMerchImage(this.checkinShopdata.shopcode, this.util.getTodayDate()).then(res_1 => {
            console.log("Res_1>>>" + JSON.stringify(res_1));
          });
        });
      });
    }
  }
  createDirectory() {
    var dir = this.checkinShopdata.shopsyskey + '/' + this.util.getTodayDate() + '/' + this.passVal + '/' + this.campaign + '/' + this.taskId;
    this.file.checkDir(this.file.externalApplicationStorageDirectory, dir)
      .then(_ => {
      })
      .catch(err => {
        console.log("errFile->" + JSON.stringify(err));
        this.file.createDir(this.file.externalApplicationStorageDirectory, this.checkinShopdata.shopsyskey, true).then(result => {
          this.file.createDir(this.file.externalApplicationStorageDirectory + this.checkinShopdata.shopsyskey, this.util.getTodayDate(), true).then(res => {
            this.file.createDir(this.file.externalApplicationStorageDirectory + this.checkinShopdata.shopsyskey + '/' + this.util.getTodayDate(), this.passVal, true).then(ress => {
              this.file.createDir(this.file.externalApplicationStorageDirectory + this.checkinShopdata.shopsyskey + '/' + this.util.getTodayDate() + '/' + this.passVal, this.campaign, true).then(ress => {
                this.file.createDir(this.file.externalApplicationStorageDirectory + this.checkinShopdata.shopsyskey + '/' + this.util.getTodayDate() + '/' + this.passVal + '/' + this.campaign, this.taskId, true).then(ress => {
                });
              });
            });
          })
        })
      });
  }
  upload() {
    this.loadingService.loadingPresent();
    var filePath = this.checkinShopdata.shopsyskey + '/' + this.util.getTodayDate() + '/' + this.passVal + '/' + this.campaign + '/' + this.taskId;
    console.log('path' + this.file.externalApplicationStorageDirectory + filePath);
    console.log("images-->" + JSON.stringify(this.images));
    var index = 0;
    if (this.images.length > 0) {
      for (var i = 0; i < this.images.length; i++) {
        index = i;
        console.log("121212-->" + index);
        console.log("try-->" + this.images[index].status + "___" + index);
        if (this.images[index].status == "notUpload") {
          var temp, tempPath, onlinePath;
          var tempName = this.images[index].img.substr(this.images[index].img.lastIndexOf('/') + 1); //.split(',')[1];
          temp = this.file.externalApplicationStorageDirectory + this.images[index].img.substr(this.images[index].img.lastIndexOf('mit.retailer.ts/') + 1).toString();
          tempPath = temp.replace("/it.retailer.ts", "");
          onlinePath = tempPath;
          tempPath = tempPath.replace(tempName, "");
          // let blob = this.b64toBlob(data, 'posts/jpeg');
          console.log("33->" + this.t1);
          // var newFileName = this.util.getTodayDate() + (Number(this.util.getCurrentTime()) + i).toString() + ".jpg";
          // console.log("222-->" + newFileName);
          // var imageName = newFileName.replace(".jpg", "");
          var newFilepath = this.file.externalApplicationStorageDirectory + filePath;
          console.log("fileName -->" + tempName + "___" + tempPath + "___" + newFilepath + "___");
          /*** Copy FIle Our Directory  */
          this.file.copyFile(tempPath, tempName, newFilepath, this.images[index].name + ".jpg").then(response => {
            console.log('copyfileres ==>' + JSON.stringify(response));
            // ACTION
          }).catch(err => {
            // ACTION
            console.log("err>" + JSON.stringify(err));
            this.loadingService.loadingDismiss();
          });
          if ((Number(this.images.length - 1)) == index) {
            // setTimeout(() =>{
            var params = {
              "list": this.params
            }
            console.log("params-->" + JSON.stringify(params));
            // var ary = [];
            this.offlineService.deleteMerchTask(this.checkinShopdata.shopcode, this.passVal, this.taskId, this.util.getTodayDate()).then(res => {
              if (res) {
                if (res) {
                  console.log("Merch>>" + JSON.stringify(res));
                  this.offlineService.insertMerchTask(this.checkinShopdata.shopcode, this.passVal, this.taskId, this.t1.toString(), this.t2, this.t3, this.taskCode, this.taskName, this.util.getTodayDate(), "uploaded", filePath).then((res: any) => {
                    console.log("Merch1>>" + JSON.stringify(res));
                    // ary.filter(obj =>{
                    console.log("imagesparam-->" + JSON.stringify(this.params));
                    this.params.filter(iobj => {
                      console.log("iobj.name" + iobj.name);
                      this.offlineService.insertMerchImage(this.checkinShopdata.shopcode, this.passVal, this.taskId, iobj.name, iobj.img, iobj.name, this.campaign, this.util.getTodayDate()).then((res: any) => {
                        console.log("Merch2>>" + JSON.stringify(res));
                      });
                    });
                    this.merchandizingService.setTaskStatus(this.taskId);
                    this.merchandizingService.addTaskRemark(this.taskId, this.remark);
                    setTimeout(() => {
                      this.loadingService.loadingDismiss();
                      this.messageService.showToast("Saved Successfully");
                      this.modalCtrl.dismiss();
                    }, 1000);
                    // });
                  });
                }
              }
            }, err => {
              console.log("error>>" + JSON.stringify(err));
              this.loadingService.loadingDismiss();
            });

            // this.onlineService.photoUpload(params).subscribe((res: any) => {
            //   console.log("upload===>" + JSON.stringify(res));
            //   ary = res.list;
            //   this.offlineService.deleteMerchTask(this.passVal, this.taskId, this.util.getTodayDate()).then(res => {
            //     if (res) {
            //       this.offlineService.deleteMerchImage(this.passVal, this.taskId, this.util.getTodayDate()).then(res => {
            //         if (res) {
            //           this.offlineService.insertMerchdizing(this.checkinShopdata.shopcode, this.passVal, this.campaign, this.brandownercode, this.brandownername, this.util.getTodayDate()).then((res: any) => {
            //             console.log("Merch>>" + JSON.stringify(res));
            //             this.offlineService.insertMerchTask(this.checkinShopdata.shopcode, this.passVal, this.taskId, this.t1.toString(), this.t2, this.t3, this.util.getTodayDate(), "uploaded", filePath).then((res: any) => {
            //               console.log("Merch1>>" + JSON.stringify(res));
            //               ary.filter(obj => {
            //                 this.offlineService.insertMerchImage(this.checkinShopdata.shopcode, this.passVal, this.taskId, obj.path, obj.name, this.campaign, this.util.getTodayDate()).then((res: any) => {
            //                   console.log("Merch2>>" + JSON.stringify(res));
            //                   this.file.copyFile(tempPath, tempName, newFilepath, newFileName).then(response => {
            //                     console.log('res ==>' + JSON.stringify(response));
            //                     // ACTION
            //                   }).catch(err => {
            //                     // ACTION
            //                     console.log("err>" + JSON.stringify(err));
            //                   });
            //                 })
            //               });
            //             });
            //           });
            //         }
            //       }, err => {
            //         console.log("error>>" + JSON.stringify(err));
            //       });
            //     }
            //   }, err => {
            //     console.log("error>>" + JSON.stringify(err));

            //   });

            //   if (res.list.length != 0) {
            //     this.messageService.showToast("Uploaded Successfully");
            //     this.loadingService.loadingDismiss();
            //     this.modalCtrl.dismiss();
            //   }
            // }, err => {
            //   this.messageService.showNetworkToast(err);
            //   this.loadingService.loadingDismiss();
            // });
            // // }, 4000);
          }

        } else {
          this.loadingService.loadingDismiss();
          this.modalCtrl.dismiss();
        }
      }
    }
    else {
      this.messageService.showToast("Please Select Photo");
      this.loadingService.loadingDismiss();
    }
  }


  async photoViewer(img, index) {
    console.log("index>>" + index);

    const modal = await this.modalCtrl.create({
      component: ImageViewerPage,
      componentProps: {
        src: img,
        index: index
      },
      // cssClass: 'ion-img-viewer',
      // keyboardClose: true,
      // showBackdrop: true
    });
    await modal.present();
    modal.onDidDismiss().then((dataReturned) => {
    });

  }
}
