import { Component, OnInit } from '@angular/core';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { UtilService } from '../services/util.service';
import { NavParams, NavController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';
import { OfflineService } from '../services/offline/offline.service';
import { OrderService } from '../services/order/order.service';
import { LoadingService } from '../services/Loadings/loading.service';
import { MessageService } from '../services/Messages/message.service';
import { OnlineService } from '../services/online/online.service';

@Component({
  selector: 'app-orderupdate',
  templateUrl: './orderupdate.page.html',
  styleUrls: ['./orderupdate.page.scss'],
})
export class OrderupdatePage implements OnInit {
  order: any = [];
  allorder: any = [];
  suborder: any = [];
  returnedproduct: any = [];
  tabs: any = [];


  params: any = this.getParams();
  child: any = [];
  subchild: any = []; //for orderlist offline
  stockbybrand: any = [];
  stockreturndata: any = [];


  checkinshop: any;
  shopinfo: any = [];

  orderno: any;
  segment: any;

  isLoading: any = false;
  open: any = false;

  constructor(private nativeStorage: NativeStorage,
    private util: UtilService,
    private activateRoute: ActivatedRoute,
    private offlineService: OfflineService,
    private orderService: OrderService,
    private navCtrl: NavController,
    private loadingService: LoadingService,
    private messageService: MessageService,
    private onlineService: OnlineService
  ) { }
  ngOnInit() {
    this.segment = 1;
    this.orderno = this.activateRoute.snapshot.paramMap.get('orderno');
    this.getOrder();
  }
  getOrder() {
    this.nativeStorage.getItem("ordershop").then((res: any) => {
      this.shopinfo = [
        {
          'shopname': res.shopname,
          'address': res.address,
          'date': this.util.getforShowDate()
        }
      ]
    });
    // this.nativeStorage.getItem("checkinShopdata").then(res => {
    //   this.checkinshop = res;
    //   this.shopinfo = [
    //     {
    //       'shopname': res.shopname,
    //       'address': res.address,
    //       'date': this.util.getforShowDate()
    //     }
    //   ]
    // });
    // this.offlineService.getOrderHdrByorderno(this.orderno).then((res: any) => {
    //   console.log("res>>" + JSON.stringify(res));

    //   // this.shopinfo = res.data.filter(obj => {
    //   //   return obj;
    //   // })
    // });
    // this.order = this.orderService.getData();
    this.order = this.orderService.getData().filter(el => el.qtystatus == "sim");
    this.allorder = this.orderService.getData();
    this.suborder = this.orderService.getData();
    this.returnedproduct = this.orderService.getData().filter(el => el.qtystatus == "exp");
    Array.from(new Set(this.order.map(s => s.brandOwnerSyskey))).map(syskey => {
      return this.tabs.push({
        'name': this.order.find(s => s.brandOwnerSyskey === syskey).brandOwnerName,
        'brandOwnerSyskey': syskey
      });
    })
    setTimeout(() => {
      this.isLoading = true;
      console.log("order>>" + JSON.stringify(this.order));
      console.log("returnorder>>" + JSON.stringify(this.returnedproduct));
      console.log("shops>>" + JSON.stringify(this.shopinfo));
    }, 1000);
  }
  segmentChanged(ev: any) {
    console.log(ev);
    this.segment = ev.detail.value;
    console.log("seg>>" + this.segment);
    if (this.segment == 1) {
      this.order = this.allorder.filter(el => el.qtystatus == "sim");
    }
    else {
      this.order = this.suborder.filter(el => el.brandOwnerSyskey == this.segment && el.qtystatus == "sim");
      console.log(">>" + this.suborder);
    }
  }
  toggleSection() {
    this.open = !this.open;
  }
  increseCart(product) {
    this.orderService.increaseProduct(product);
  }
  decreseCart(product) {
    this.orderService.decreaseProduct(product);
  }


  deleteCart(product) {
    this.loadingService.loadingPresent();
    this.orderService.deleteCart(product);
    this.getOrder();
    setTimeout(() => {
      this.loadingService.loadingDismiss();
    }, 2000);
  }
  getSubTotal() {
    return this.allorder.reduce((i, j) => i + j.price * j.amount, 0);
  }
  getTotal() {
    return this.allorder.reduce((i, j) => i + j.price * j.amount, 0);
  }
  dateFormat(date) {
    let year = date.substring(0, 4);
    let month = date.substring(4, 6);
    let day = date.substring(6, 8);
    let val = day + '/' + month + '/' + year;
    return val;
  }
  getParams() {
    return { "syskey": '', "autokey": "", "createddate": '', "modifieddate": '', "userid": '', 'username': '', 'saveStatus': '', 'recordStatus': '', 'syncStatus': '', 'syncBatch': '', 'transType': '', 'manualRef': '', 'docummentDate': '', 'shopCode': '', 'currRate': '', 'totalamount': '', 'cashamount': '', 'discountamount': '', 'taxSyskey': '', 'taxPercent': '', 'taxAmount': '', 'previousId': '', 'stockByBrand': [] };
  }

  updateOrder() {
    if (this.allorder.length == 0) {
      this.messageService.showToast("No data in shopping cart");
    }
    else {
      this.params = this.getParams();
      this.loadingService.loadingPresent();
      this.params.syskey = this.orderno.toString();
      this.params.autokey = "";
      this.params.createddate = "";
      this.params.modifieddate = "";
      this.params.userid = "";
      this.params.username = "";
      this.params.saveStatus = 1;
      this.params.recordStatus = 1;
      this.params.syncStatus = 1;
      this.params.syncBatch = "";
      this.params.transType = "SalesOrder";
      this.params.manualRef = "TBA";
      this.params.docummentDate = this.util.getTodayDate();
      this.shopinfo.filter(obj => {
        if (obj.shopCode == null) {
          this.params.shopCode = obj.shopCode;
        }
        else {
          this.params.shopCode = obj.shopCode.toString();
        }
      })
      this.params.currRate = 1.0;
      this.params.cashamount = 1.0;
      this.params.discountamount = 1.0;
      this.params.taxSyskey = "0";
      this.params.taxPercent = 1.0;
      this.params.taxAmount = 1.0;
      this.params.previousId = "0";
      this.params.totalamount = this.allorder.reduce((i, j) => i + j.price * j.amount, 0);
      var shop = this.shopinfo.filter(el => { return el.shopCode });
      console.log("shopcode" + shop);
      //---------part of Stockbybrand [start]-------------
      const data = Array.from(new Set(this.allorder.map(s => s.brandOwnerSyskey))).map(syskey => {
        return {
          'brandOwnerName': this.allorder.find(s => s.brandOwnerSyskey === syskey).brandOwnerName,
          'whSyskey': this.allorder.find(s => s.brandOwnerSyskey === syskey).whSyskey,
          'brandOwnerSyskey': syskey,
          'brandSyskey': this.allorder.find(s => s.brandOwnerSyskey === syskey).brandSyskey
        };
      })
      data.filter(bobj => {
        this.stockbybrand = [];
        this.stockreturndata = [];
        this.child = [];
        var stockdata;
        this.stockbybrand.push({
          "syskey": bobj.brandSyskey,
          "autokey": "",
          "createdate": "",
          "modifieddate": "",
          "userid": "",
          "username": '',
          "saveStatus": 1,
          "recordStatus": 1,
          "syncStatus": 1,
          "syncBatch": "",
          "transType": "SalesOrder",
          "transId": "",
          "docummentDate": this.util.getTodayDate(),
          "brandOwnerCode": "",
          "brandOwnerName": bobj.brandOwnerName,
          "brandOwnerSyskey": bobj.brandOwnerSyskey,
          "orderSyskey": "",
          "totalamount": 0.0,
          "cashamount": 0.0,
          "discountamount": 0.0,
          "taxSyskey": "",
          "taxAmount": 0.0,
          "stockData": [],
          "stockReturnData": []
        });
        stockdata = this.allorder.filter(el => el.brandOwnerSyskey == bobj.brandOwnerSyskey && el.qtystatus == "sim");
        stockdata.filter(sobj => {
          this.child.push({
            "syskey": sobj.syskey,
            "recordStatus": 1,
            "stockCode": sobj.code,
            "saleCurrCode": "MMK",
            "n1": "",
            "wareHouseSyskey": sobj.whSyskey,
            "binSyskey": "0",
            "qty": sobj.amount,
            "lvlSyskey": "390398473894233",
            "lvlQty": parseInt('0'),
            "n8": 0.0,
            "n9": 0.0,
            "taxAmount": 0.0,
            "totalAmount": parseInt(sobj.price) * parseInt(sobj.amount),
            "taxCodeSK": "0",
            "isTaxInclusice": 0,
            "taxPercent": 0.0
          });
        });
        this.child.filter(obj => {
          this.stockbybrand.reduce((i, j) => i + j.stockData.push(obj), 0);
        });
        //--------part of stockbybrand [end]---------
        const returnstockdata = this.allorder.filter(el => el.brandOwnerSyskey == bobj.brandOwnerSyskey && el.qtystatus == "exp").map(val => {
          return val;
        });
        console.log("Returnstockdata>>" + JSON.stringify(returnstockdata));
        returnstockdata.filter(sobj => {
          this.stockreturndata.push({
            "syskey": sobj.syskey,
            "stockCode": sobj.code,
            "saleCurrCode": "MMK",
            "n1": "",
            "wareHouseSyskey": sobj.whSyskey,
            "binSyskey": "0",
            "qty": sobj.amount,
            "lvlSyskey": "390398473894233",
            "lvlQty": parseInt('0'),
            "n8": 0.0,
            "n9": 0.0,
            "taxAmount": 0.0,
            "totalAmount": parseInt(sobj.price) * parseInt(sobj.amount),
            "taxCodeSK": "0",
            "isTaxInclusice": 0,
            "taxPercent": 0.0
          });
        });
        this.stockreturndata.filter(obj => {
          if (obj) {
            this.stockbybrand.reduce((i, j) => i + j.stockReturnData.push(obj), 0);
          }
        })
        this.stockbybrand.filter(obj => {
          if (obj) {
            console.log("stockfdskjl>" + JSON.stringify(obj));
            this.params.stockByBrand.push(obj);
          }
        });
      });

      console.log("Data>>" + JSON.stringify(this.params));
      setTimeout(() => {
        this.onlineService.saveOrder(this.params).subscribe((res: any) => {
          console.log("Save order==>" + JSON.stringify(res));
          if (res.status == "SUCCESS") {
            var orderno = res.data.syskey;
            // this.offlineService.deleteOrderHdr(orderno).then(res => {
            //   if (res) {
            //     this.offlineService.deleteOrderBdy(orderno).then(res => {
            //       if (res) {
            //         this.shopinfo.filter(obj => {
            //           this.offlineService.insertOrderhdr({ syskey: this.orderno, date: this.util.getTodayDate, orderno: orderno, shopname: obj.shop_name, shopCode: this.checkinshop.shopcode.toString(), address: obj.address, usercode: this.shopinfo.userId }).then(res => {
            //             const data = Array.from(new Set(this.allorder.map(s => s.brandOwnerSyskey))).map(syskey => {
            //               return {
            //                 'brandOwnerName': this.allorder.find(s => s.brandOwnerSyskey === syskey).brandOwnerName,
            //                 'whSyskey': this.allorder.find(s => s.brandOwnerSyskey === syskey).whSyskey,
            //                 'brandOwnerSyskey': syskey
            //               };
            //             })
            //             data.filter(bobj => {
            //               this.subchild = [];
            //               this.allorder.filter(sobj => {
            //                 this.subchild.push({ // for save offline
            //                   "stockCode": sobj.code,
            //                   "saleCurrCode": "MMK",
            //                   "n1": "",
            //                   "wareHouseSyskey": bobj.whSyskey,
            //                   "brandOwnerName": bobj.brandOwnerName,
            //                   "brandOwnerSyskey": bobj.brandOwnerSyskey,
            //                   "desc": sobj.desc,
            //                   "binSyskey": "0",
            //                   "qty": sobj.amount,
            //                   "lvlSyskey": "390398473894233",
            //                   "lvlQty": parseInt('0'),
            //                   "n8": 0.0,
            //                   "n9": 0.0,
            //                   "taxAmount": 0.0,
            //                   "totalAmount": parseInt(sobj.price),
            //                   "taxCodeSK": "0",
            //                   "isTaxInclusice": 0,
            //                   "taxPercent": 0.0,
            //                   "expqty": sobj.expqty
            //                 });
            //               });
            //             })
            //             for (var c = 0; c < this.subchild.length; c++) {
            //               if (this.subchild[c].expqty) {
            //                 this.offlineService.insertOrderbdy({ orderno: orderno, stocksyskey: this.subchild[c].syskey, stockcode: this.subchild[c].stockCode, stockname: this.subchild[c].desc, brandOwnerName: this.subchild[c].brandOwnerName, brandOwnerSyskey: this.subchild[c].brandOwnerSyskey, whSyskey: this.subchild[c].wareHouseSyskey, qty: this.subchild[c].qty, price: this.subchild[c].totalAmount, brandowner: "we", owner: '3', note: "good job", qtystatus: 'exp' }).then(response => {
            //                 });
            //               }
            //               else {
            //                 this.offlineService.insertOrderbdy({ orderno: orderno, stocksyskey: this.subchild[c].syskey, stockcode: this.subchild[c].stockCode, stockname: this.subchild[c].desc, brandOwnerName: this.subchild[c].brandOwnerName, brandOwnerSyskey: this.subchild[c].brandOwnerSyskey, whSyskey: this.subchild[c].wareHouseSyskey, qty: this.subchild[c].qty, price: this.subchild[c].totalAmount, brandowner: "we", owner: '3', note: "good job", qtystatus: 'sim' }).then(response => {
            //                 });
            //               }
            //               console.log("orderno" + orderno);
            //             }
            //           });
            //         })
            //       }
            //     });
            //   }
            // });
            this.loadingService.loadingDismiss();
            this.navCtrl.navigateBack([`main`]);
            this.messageService.showToast("Saved successfully.");
          }
          else {
            this.loadingService.loadingDismiss();
            this.messageService.showToast("Something wrong!.");
          }
        }, err => {
          console.log("err=>" + JSON.stringify(err));
          this.messageService.showNetworkToast(err);
          this.loadingService.loadingDismiss();
        });
      }, 100);
    }
  }
}
