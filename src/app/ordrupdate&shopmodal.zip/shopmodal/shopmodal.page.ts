import { Component, OnInit } from '@angular/core';
import { OfflineService } from '../services/offline/offline.service';
import { UtilService } from '../services/util.service';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { CartService } from '../services/cart/cart.service';
import { OnlineService } from '../services/online/online.service';
import { LoadingService } from '../services/Loadings/loading.service';
import { NavController, ModalController } from '@ionic/angular';
import { MessageService } from '../services/Messages/message.service';

@Component({
  selector: 'app-shopmodal',
  templateUrl: './shopmodal.page.html',
  styleUrls: ['./shopmodal.page.scss'],
})
export class ShopmodalPage implements OnInit {
  shoplist: any = [];
  loginData: any;
  selectedRadioGroup: any;
  selectedRadioItem: any;

  selectshopdata: any;
  constructor(private offlineService: OfflineService, private util: UtilService,
    private nativeStorage: NativeStorage,
    private cartService: CartService,
    private onlineService: OnlineService,
    private messageService: MessageService,
    private loadingService: LoadingService,
    private navCtrl: NavController,
    private modalCtrl: ModalController) { }

  ngOnInit() {
    this.nativeStorage.getItem("loginData").then(res => {
      this.loginData = res;
      console.log("loginData -->" + JSON.stringify(this.loginData));
      this.getShopList();
    });
  }

  getShopList() {
    this.offlineService.getdatasfromShopbyuser(this.util.getTodayDate(), this.loginData.userId).then((shop_res: any) => {
      console.log("shop_res-->" + JSON.stringify(shop_res));
      for (var qe = 0; qe < shop_res.data.length; qe++) {
        this.shoplist.push(
          {
            id: shop_res.data[qe].id,
            shopcode: shop_res.data[qe].shopcode,
            address: shop_res.data[qe].address,
            shopsyskey: shop_res.data[qe].shopsyskey,
            shopname: shop_res.data[qe].shopname,
            checked: false
          }
        );
      }
    })
      .catch(shop_err => {
        console.log("shop_err-->" + JSON.stringify(shop_err));
      });
  }

  radioGroupChange(event) {
    console.log("radioGroupChange", event.detail);
    this.selectedRadioGroup = event.detail;
  }

  radioFocus() {
    console.log("radioFocus");
  }
  radioSelect(event) {
    console.log("radioSelect", event.detail);
    this.selectedRadioItem = event.detail;
  }
  closeModal() {
    this.modalCtrl.dismiss();
  }
  selectShop() {
    console.log("selectedRadio>" + this.selectedRadioGroup);

    if (this.selectedRadioGroup) {
      this.modalCtrl.dismiss();
      this.loadingService.loadingPresent();
      var shop = this.shoplist.filter(el => el.shopcode == this.selectedRadioGroup.value);
      shop.filter(obj => {
        this.selectshopdata = {
          'shopcode': obj.shopcode,
          'shopname': obj.shopname,
          'address': obj.address
        }
      })

      console.log("selectshopdata>>>" + JSON.stringify(this.selectshopdata));
      var param = {
        'shopcode': this.selectedRadioGroup.value,
        'date': '',
        'trantype': 'SalesOrder'
      };
      console.log("param" + JSON.stringify(param));
      this.offlineService.deleteAllOrderHdr().then(res => {
        this.offlineService.deleteAllOrderBdy().then(res => {
          this.onlineService.getOrderList(param).subscribe((res: any) => {
            console.log("data>>>" + JSON.stringify(res));
            var data = res.list;
            data.filter(hdrobj => {
              console.log("hdrobj<<" + JSON.stringify(hdrobj));
              this.offlineService.insertOrderhdr({ syskey: hdrobj.syskey, date: hdrobj.createddate, orderno: hdrobj.syskey, shopname: this.selectshopdata.shopname, shopCode: this.selectshopdata.shopcode, address: this.selectshopdata.address, usercode: this.loginData.userId }).then(res => {
                hdrobj.stockByBrand.filter(brandobj => {
                  if (brandobj.stockData.length > 0) {
                    brandobj.stockData.filter(stockobj => {
                      var stockname = this.cartService.getStockName(stockobj.stockCode);
                      this.offlineService.insertOrderbdy({ orderno: hdrobj.syskey, stocksyskey: stockobj.syskey, stockcode: stockobj.stockCode, stockname: stockname, brandSyskey: brandobj.syskey, brandOwnerName: brandobj.brandOwnerName, brandOwnerSyskey: brandobj.brandOwnerSyskey, whSyskey: stockobj.wareHouseSyskey, qty: stockobj.qty, price: stockobj.totalAmount, brandowner: "we", owner: '3', note: "good job", qtystatus: 'exp' }).then(response => {
                      });
                    });
                  }
                  if (brandobj.stockReturnData.length > 0) {
                    brandobj.stockReturnData.filter(restockobj => {
                      var stockname = this.cartService.getStockName(restockobj.stockCode);
                      this.offlineService.insertOrderbdy({ orderno: hdrobj.syskey, stocksyskey: restockobj.syskey, stockcode: restockobj.stockCode, stockname: stockname, brandSyskey: brandobj.syskey, brandOwnerName: brandobj.brandOwnerName, brandOwnerSyskey: restockobj.brandOwnerSyskey, whSyskey: restockobj.wareHouseSyskey, qty: restockobj.qty, price: restockobj.totalAmount, brandowner: "we", owner: '3', note: "good job", qtystatus: 'sim' }).then(response => {
                      });
                    })
                  }
                });
              });
            });
            console.log("main");
            setTimeout(() => {
              this.nativeStorage.remove("ordershop");
              var data = {
                'shopname': this.selectshopdata.shopname,
                'shopcode': this.selectshopdata.shopcode,
                'address': this.selectshopdata.address
              }
              this.nativeStorage.setItem("ordershop", data);
              this.loadingService.loadingDismiss();
              this.navCtrl.navigateForward(['order-list']);
            }, 3000);
          });
        });
      });
    }
    else {
      this.messageService.showToast("Select shop");
      this.loadingService.loadingDismiss();
    }
  }
}
